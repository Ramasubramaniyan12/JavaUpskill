package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(name="order-service")
public class OrderController {

	@GetMapping("/order")
	public String order(){
		return"List of order from ORDER-SERVICE";
	}
}
