package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(name="product-service")
public class ProductController {

	@GetMapping("/product")
	public String product() {
		return"product from PRODUCT-SERVICE";
	}
}
